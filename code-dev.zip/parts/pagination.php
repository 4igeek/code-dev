<div class="code-dev-pagination">
    <div class="pages new"><?php previous_posts_link( esc_html__('<< Newer Posts', 'code-dev') ) ; ?></div>
    <div class="pages old"><?php next_posts_link( esc_html__('Older Posts >>', 'code-dev')); ?></div>
</div>