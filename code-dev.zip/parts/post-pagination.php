<div class="code-dev-pagination">
    <div class="pages next"><?php next_post_link('&laquo; %link'); ?></div>
    <div class="pages previous"><?php previous_post_link('%link &raquo; '); ?></div>
</div>